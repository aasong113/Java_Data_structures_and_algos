package hw1;

/**
 * 
 * @author Anthony Song
 *
 */

/*
 * A rabbit eats grass and lives no more than three years.
 */
public class Rabbit extends Animal {
	/**
	 * Creates a Rabbit object.
	 * 
	 * @param p: plain
	 * @param r: row position
	 * @param c: column position
	 * @param a: age
	 */
	public Rabbit(Plain p, int r, int c, int a) {
		plain = p;
		row = r;
		column = c;
		age = a;
		// TODO
	}

	// Rabbit occupies the square.
	public State who() {
		// TODO
		return State.RABBIT;
	}

	/**
	 * A rabbit dies of old age or hunger. It may also be eaten by a badger or a
	 * fox.
	 * 
	 * @param pNew plain of the next cycle
	 * @return Living new life form occupying the same square
	 */
	public Living next(Plain pNew) {
		// TODO
		//
		// See Living.java for an outline of the function.
		// See the project description for the survival rules for a rabbit.

		int[] population = new int[NUM_LIFE_FORMS];
		
		census(population);

		/*
		 * BADGER = 0; EMPTY = 1; FOX = 2; GRASS = 3; RABBIT = 4;
		 */

		// If rabbit is 3 it dies, or if there is no grass in the neighborhood.
		if ((age == Living.RABBIT_MAX_AGE) || (population[3] == 0)) {
			return new Empty(pNew, row, column);
		}

		// If there are the same number or more rabbits than badgers and foxes.
		if (((population[4]) <= (population[0] + population[2]))) {

			// if there are more foxes than badgers, the square is a badger.
			if ((population[2] > population[0])) {
				return new Fox(pNew, row, column, 0);
			}

		}

		// if there are more badgers than rabbits in the neighborhood.
		if (population[0] > (population[4])) {
			return new Badger(pNew, row, column, 0);
		}

		// increase age and return rabbit.
		age++;
		return this;

	}
}

// Check AS