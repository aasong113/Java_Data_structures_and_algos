package hw1;

/**
 *  
 * @author Anthony Song
 *
 */

import org.junit.Test;
import static org.junit.Assert.*;

import java.io.FileNotFoundException;

public class BadgerTest {
	
	
	
	@Test 
	// If there is only one badger, but there is more than one fox.
	/*
	R0 G  R0
	E  B2 G 
	F1 F0 E
	*/
	// there are 2 foxes, and one badger, the B2 should be empty. 
	public void testSpecB() throws FileNotFoundException {
		
		String fileName = "test_badger_spec_B.txt";
		
		Plain p = new Plain(fileName);
		
		State object = p.grid[1][1].next(p).who();
		
		assertEquals(State.FOX, object);
		
	}
	
	@Test
	// Empty if Badgers and foxes together outnumber rabbits in the neighborhood.
	/*
	R0 G  R0
	E  B2 B0 
	E  F0 E
	*/
	// Should be empty because two badgers + one foxes outnumber two rabbits. 
	
public void testSpecC() throws FileNotFoundException {
		
		String fileName = "test_badger_spec_C.txt";
		
		Plain p = new Plain(fileName);
		
		State object = p.grid[1][1].next(p).who();
		
		assertEquals(State.EMPTY, object);
		
	}

}

// Check AS
