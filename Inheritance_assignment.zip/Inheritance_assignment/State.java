package hw1;

/**
 *  
 * @author Anthony Song
 *
 */

/**
 * 
 * Different forms of life. 
 *
 */
public enum State 
{
	BADGER, EMPTY, FOX, GRASS, RABBIT 
}

//Check AS