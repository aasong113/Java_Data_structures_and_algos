package hw1;

/**
 *  
 * @author Anthony Song
 *
 */

import org.junit.Test;
import static org.junit.Assert.*;

import java.io.FileNotFoundException;

public class EmptyTest {
	
	
	
	@Test 
	// Rabbit if more than one neighboring rabbit. 
	/*
	E  R0  E
	R1 G  B0 
	F0 E  F2
	*/ 
	public void testSpecA() throws FileNotFoundException {
		
		String fileName = "test_empty_spec_A.txt";
		
		Plain p = new Plain(fileName);
		
		State object = p.grid[0][0].next(p).who();
		
		assertEquals(State.RABBIT, object);
		
	}
	
	@Test
	// Fox if more than one neighboring box.   
	/*
	E  R0  E
	R1 G  B0 
	F0 E  F2
	*/
	// 
	
public void testSpecB() throws FileNotFoundException {
		
		String fileName = "test_empty_spec_A.txt";
		
		Plain p = new Plain(fileName);
		
		State object = p.grid[2][1].next(p).who();
		
		assertEquals(State.FOX, object);
		
	}	
	
	
	@Test
	// Badger if more than one neighboring badger.   
	/*
	E  R0  E
	B1 G  B0 
	B0 E  R2
	*/
	// 
	
public void testSpecC() throws FileNotFoundException {
		
		String fileName = "test_empty_spec_B.txt";
		
		Plain p = new Plain(fileName);
		
		State object = p.grid[2][1].next(p).who();
		
		assertEquals(State.BADGER, object);
		
	}
	
	
	@Test
	// Grass if at least one neighboring grass.  
	/*
	E  R0  E
	B1 G  B0 
	B0 E  R2
	*/
	// 
	
public void testSpecD() throws FileNotFoundException {
		
		String fileName = "test_empty_spec_B.txt";
		
		Plain p = new Plain(fileName);
		
		State object = p.grid[0][2].next(p).who();
		
		assertEquals(State.GRASS, object);
		
	}
	

}

// Check AS