package hw1;

/**
 *  
 * @author Anthony Song
 *
 */

import org.junit.Test;
import static org.junit.Assert.*;

import java.io.FileNotFoundException;

public class WildLifeTest {

	@Test
	// public 1
	public void testPublic1_3x3() throws FileNotFoundException {

		Plain p_initial = new Plain("public1-3x3.txt");

		Plain dummy = new Plain(3);

		for (int i = 0; i < 5; i++) {
			Wildlife.updatePlain(p_initial, dummy);

		}

		Plain p_final = new Plain("public1-5cycles.txt");

		assertEquals(p_initial.toString(), p_final.toString());

	}
	
	@Test
	public void testPublic2_6x6() throws FileNotFoundException {

		Plain p_initial = new Plain("public2-6x6.txt");

		Plain dummy = new Plain(6);

		for (int i = 0; i < 8; i++) {
			Wildlife.updatePlain(p_initial, dummy);

		}

		Plain p_final = new Plain("public2-8cycles.txt");

		assertEquals(p_initial.toString(), p_final.toString());

	}

	
	@Test
	public void testPublic3_10x10() throws FileNotFoundException {

		Plain p_initial = new Plain("public3-10x10.txt");

		Plain dummy = new Plain(10);

		for (int i = 0; i < 6; i++) {
			Wildlife.updatePlain(p_initial, dummy);

		}

		Plain p_final = new Plain("public3-6cycles.txt");

		assertEquals(p_initial.toString(), p_final.toString());

	}
	
	@Test
	public void test2_6x6() throws FileNotFoundException {

		Plain p_initial = new Plain("test2.txt");

		Plain dummy = new Plain(10);

		for (int i = 0; i < 8; i++) {
			Wildlife.updatePlain(p_initial, dummy);

		}

		Plain p_final = new Plain("test2_8cycles.txt");

		assertEquals(p_initial.toString(), p_final.toString());

	}
	
	

}

// Check AS