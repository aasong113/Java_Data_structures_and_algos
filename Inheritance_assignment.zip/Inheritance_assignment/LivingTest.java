package hw1;

/**
 *  
 * @author Anthony Song
 *
 */

import org.junit.Test;
import static org.junit.Assert.*;

import java.io.FileNotFoundException;

public class LivingTest {

	
	
	/*
	R0 G  R0
	E  B2 G 
	F1 F0 E
	*/
	
	/*
	 * BADGER = 0; EMPTY = 1;
	 * FOX = 2; GRASS = 3;
	 * RABBIT = 4;
	 */
	
	@Test
	public void censusTest() throws FileNotFoundException {
		
		Plain p = new Plain("test_badger_spec_B.txt");
		
		int[] testArray = new int[] {1, 2, 2, 2, 2};
		
		int[] population = new int[5];
		
		p.grid[1][1].census(population);
		
		assertArrayEquals(testArray, population);
		
	}
	
	@Test
	public void whoTest() throws FileNotFoundException {
		
		Plain p = new Plain("test_badger_spec_B.txt");
		
		assertEquals(p.grid[1][1].who(), State.BADGER);
		assertEquals(p.grid[0][0].who(), State.RABBIT);
		assertEquals(p.grid[2][2].who(), State.EMPTY);
		assertEquals(p.grid[2][0].who(), State.FOX);
		assertEquals(p.grid[1][2].who(), State.GRASS);
		
	}
	
	
	
	
	
}

// Check AS
