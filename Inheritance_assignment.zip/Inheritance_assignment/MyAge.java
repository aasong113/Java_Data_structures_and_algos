package hw1;

/**
 *  
 * @author Anthony Song
 *
 */

/**
 * 
 * To be implemented by the Animal class. 
 *
 */
public interface MyAge 
{
	int myAge();	// return age of the animal
}

// Check AS
