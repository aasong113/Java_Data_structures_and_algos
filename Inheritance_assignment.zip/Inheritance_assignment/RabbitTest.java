package hw1;

/**
 *  
 * @author Anthony Song
 *
 */

import org.junit.Test;
import static org.junit.Assert.*;

import java.io.FileNotFoundException;

public class RabbitTest {
	
	
	
	@Test 
	// Empty if there is no grass in the neighborhood. 
	/*
	B5 E  E
	B3 R1 B0 
	R0 E  R2
	*/ 
	public void testSpecB() throws FileNotFoundException {
		
		String fileName = "test_rabbit_spec_B.txt";
		
		Plain p = new Plain(fileName);
		
		State object = p.grid[1][1].next(p).who();
		
		assertEquals(State.EMPTY, object);
		
	}
	
	@Test
	// Fox if in neighborhood there are at least as many foxes and badgers as rabbits
	// and if more foxes than badgers. 
	/*
	B5 G  E
	F3 R1 F0 
	R0 G  R2
	*/
	// 
	
public void testSpecC() throws FileNotFoundException {
		
		String fileName = "test_rabbit_spec_C.txt";
		
		Plain p = new Plain(fileName);
		
		State object = p.grid[1][1].next(p).who();
		
		assertEquals(State.FOX, object);
		
	}
	
	@Test
	// Otherwise, badger if there are more badgers than rabbits in the neighborhood. 
	/*
	B5 G  E
	B3 R1 B0 
	G  G  R2
	*/
	
	
public void testSpecD() throws FileNotFoundException {
		
		String fileName = "test_rabbit_spec_D.txt";
		
		Plain p = new Plain(fileName);
		
		State object = p.grid[1][1].next(p).who();
		
		assertEquals(State.BADGER, object);
		
	}
	
	
	
	
	

}

// Check AS