package hw1;

/**
 *  
 * @author Anthony Song
 *
 */

import org.junit.Test;
import static org.junit.Assert.*;

import java.io.FileNotFoundException;

public class PlainTest {

	@Test
	public void testGridWidth() {
		
		int w = 3;
		
		Plain p = new Plain(3);
		
		assertEquals(p.getWidth(), w);
		
	}
	
	
	@Test 
	public void testInput_Output() throws FileNotFoundException {
		
	Plain p = new Plain("public3-10x10.txt");
	
	Plain dummy = new Plain(10);
	
	for (int i = 0; i < 6; i++) {
		Wildlife.updatePlain(p, dummy);

	}
	
	dummy.write("J_unit_test.txt");
	
	
	Plain check = new Plain("public3-6cycles.txt");
	
	Plain junit = new Plain("J_unit_test.txt");
	
	
	assertEquals(dummy.toString(), check.toString());
	assertEquals(junit.toString(), dummy.toString());
	
		
	}
	
	
	
	
}

// Check AS
