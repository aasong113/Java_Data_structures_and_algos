package hw1;

import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *  
 * @author Anthony Song
 *
 */

/**
 * 
 * The Wildlife class performs a simulation of a grid plain with squares
 * inhabited by badgers, foxes, rabbits, grass, or none.
 *
 */
public class Wildlife {

	/**
	 * Update the new plain from the old plain in one cycle.
	 * 
	 * @param pOld old plain
	 * @param pNew new plain
	 */
	public static void updatePlain(Plain pOld, Plain pNew) {

		for (int i = 0; i < pOld.getWidth(); i++) {

			for (int j = 0; j < pOld.getWidth(); j++) {

				pNew.grid[i][j] = pOld.grid[i][j].next(pOld);

			}

		}

		// Deep copy of grid in order to do next iteration.
		for (int i = 0; i < pOld.getWidth(); i++) {

			for (int j = 0; j < pOld.getWidth(); j++) {

				pOld.grid[i][j] = pNew.grid[i][j];

			}

		}

		// TODO
		//
		// For every life form (i.e., a Living object) in the grid pOld, generate
		// a Living object in the grid pNew at the corresponding location such that
		// the former life form changes into the latter life form.
		//
		// Employ the method next() of the Living class.

	}

	/**
	 * Repeatedly generates plains either randomly or from reading files. Over each
	 * plain, carries out an input number of cycles of evolution.
	 * 
	 * @param args
	 * @throws FileNotFoundException
	 */
	public static void main(String[] args) throws FileNotFoundException {
		// TODO
		//
		// Generate wildlife simulations repeatedly like shown in the
		// sample run in the project description.
		//
		// 1. Enter 1 to generate a random plain, 2 to read a plain from an input
		// file, and 3 to end the simulation. (An input file always ends with
		// the suffix .txt.) Use a while loop.

		Scanner input = new Scanner(System.in);

		boolean finished = false;
		int trial_num = 1;

		System.out.println("Simulation of Wildlife of the Plain");
		System.out.println("keys: 1 (random plain) 2 (file input) 3 (exit)");

		// This loop is only exited when you enter the number 3.
		while (!finished) {

			boolean correct = false;

			int option = 0;

			// this is where you enter a one of the three options
			// while loop ends when a valid option is entered. .
			while (!correct) {

				try {
					System.out.print("Trial " + trial_num + ": ");

					option = Integer.parseInt(input.next());

					if (option == 1 || option == 2 || option == 3) {

						correct = true;
					}

				} catch (NumberFormatException ne) {

					System.out.println();

				}

			}

			// increase trial number
			trial_num++;

			// make plain object.
			Plain even = null; // the plain after an even number of cycles
			Plain odd = null;

			switch (option) {

			// Random Plain Case 1
			case 1:
				System.out.println("Random Plain");

				boolean valid = false;
				int grid_width;

				// get valid grid width.
				while (!valid) {

					try {
						System.out.print("Enter grid width: ");

						grid_width = Integer.parseInt(input.next());

						// grid must be greater than or equal to one.
						if (grid_width >= 1) {

							even = new Plain(grid_width);
							odd = new Plain(grid_width);

							valid = true;
						}

					} catch (NumberFormatException ne) {

					}
				}

				valid = false;
				int num_cycles = 0;

				// get valid number of cycles.
				while (!valid) {

					try {
						System.out.print("Enter the number of cycles: ");

						num_cycles = Integer.parseInt(input.next());

						// must be greater than or equal to zero.
						if (num_cycles >= 0) {

							valid = true;

						}

					} catch (NumberFormatException ne) {

					}
				}

				System.out.println("Initial plain");
				System.out.println();
				System.out.println(even.toString());
				System.out.println();

				// if even number of cycles.

				if (num_cycles % 2 == 0) {

					for (int i = 0; i < num_cycles; i++) {
						updatePlain(odd, even);

					}

					System.out.println("Final plain");
					System.out.println();
					System.out.println(even.toString());
					System.out.println();

				}

				// if odd number of cycles.

				else {

					for (int i = 0; i < num_cycles; i++) {
						updatePlain(even, odd);
					}
					System.out.println("Final plain");
					System.out.println();
					System.out.println(odd.toString());
					System.out.println();

				}

				break;

			// Input file case 2.
			case 2:

				System.out.println("Plain input from a file");

				boolean valid2 = false;

				// get valid grid width.
				while (!valid2) {

					try {
						System.out.print("File name: ");

						String file_name = input.next();

						even = new Plain(file_name);
						odd = new Plain(file_name);

						valid2 = true;

					} catch (FileNotFoundException ne) {

					}
				}

				valid2 = false;
				int num_cycles2 = 0;

				// get valid number of cycles.
				while (!valid2) {

					try {
						System.out.print("Enter the number of cycles: ");

						num_cycles2 = Integer.parseInt(input.next());

						// must be positive number or zero.
						if (num_cycles2 >= 0) {

							valid2 = true;

						}

					} catch (NumberFormatException ne) {

					}
				}

				System.out.println("Initial plain");
				System.out.println();
				System.out.println(even.toString());
				System.out.println();

				// if even number of cycles.

				if (num_cycles2 % 2 == 0) {

					for (int i = 0; i < num_cycles2; i++) {
						updatePlain(odd, even);

					}
					System.out.println("Final plain");
					System.out.println();
					System.out.println(even.toString());
					System.out.println();

				}

				// if odd number of cycles.

				else {

					for (int i = 0; i < num_cycles2; i++) {
						updatePlain(even, odd);

					}
					System.out.println("Final plain");
					System.out.println();
					System.out.println(odd.toString());
					System.out.println();

				}

				break;

			// breaks while loop. program is over Case 3 end program.
			case 3:
				finished = true;
				break;

			}

		}

		input.close();

	}

	//
	// 2. Print out standard messages as given in the project description.
	//
	// 3. For convenience, you may define two plains even and odd as below.
	// In an even numbered cycle (starting at zero), generate the plain
	// odd from the plain even; in an odd numbered cycle, generate even
	// from odd.
	// the plain after an odd number of cycles

	// 4. Print out initial and final plains only. No intermediate plains should
	// appear in the standard output. (When debugging your program, you can
	// print intermediate plains.)
	//
	// 5. You may save some randomly generated plains as your own test cases.
	//
	// 6. It is not necessary to handle file input & output exceptions for this
	// project. Assume data in an input file to be correctly formated.
}

// Check AS
