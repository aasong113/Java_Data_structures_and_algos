package hw1;

/**
 *  
 * @author Anthony Song
 *
 */

import org.junit.Test;
import static org.junit.Assert.*;

import java.io.FileNotFoundException;

public class FoxTest {
	
	
	
	@Test 
	// If there are more badgers than foxes in the neighborhood. 
	/*
	B5 E  E
	B3 F1 B0 
	R0 E  R2
	*/
	// There are three badgers in the neighborhood, should be badger. 
	public void testSpecB() throws FileNotFoundException {
		
		String fileName = "test_fox_spec_B.txt";
		
		Plain p = new Plain(fileName);
		
		State object = p.grid[1][1].next(p).who();
		
		assertEquals(State.BADGER, object);
		
	}
	
	@Test
	// Empty if Badgers and foxes together outnumber rabbits in the neighborhood.
	/*
	B5 E  E
	E  F1 B0 
	R0 E  F0
	*/
	// Should be empty because two badgers + two foxes outnumber one rabbit. 
	
public void testSpecC() throws FileNotFoundException {
		
		String fileName = "test_badger_spec_C.txt";
		
		Plain p = new Plain(fileName);
		
		State object = p.grid[1][1].next(p).who();
		
		assertEquals(State.EMPTY, object);
		
	}

}

// Check AS