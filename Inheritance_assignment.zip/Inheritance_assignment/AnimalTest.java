package hw1;

/**
 *  
 * @author Anthony Song
 *
 */

import org.junit.Test;
import static org.junit.Assert.*;

public class AnimalTest {
	
	@Test
	
	public void test_return_age() {
	
		Plain p = new Plain(4);
		
		Badger b = new Badger(p, 2, 1, 2);
		
		assertEquals(2, b.myAge());
		
	}

}

// Check AS
