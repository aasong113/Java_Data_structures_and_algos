package hw1;

/**
 *  
 * @author Anthony Song
 *
 */

import org.junit.Test;
import static org.junit.Assert.*;

import java.io.FileNotFoundException;

public class GrassTest {
	
	
	
	@Test 
	// Empty if at least 3 times as many rabbits as grasses in neighborhood. 
	/*
	B5 E  E
	R1 G  B0 
	R0 E  R2
	*/ 
	public void testSpecA() throws FileNotFoundException {
		
		String fileName = "test_grass_spec_A.txt";
		
		Plain p = new Plain(fileName);
		
		State object = p.grid[1][1].next(p).who();
		
		assertEquals(State.EMPTY, object);
		
	}
	
	@Test
	// Rabbit if there are at least 3 rabbits in the neighborhood.  
	/*
	B5 E  E
	R1 G  R0 
	R0 E  G
	*/
	// 
	
public void testSpecB() throws FileNotFoundException {
		
		String fileName = "test_Grass_spec_B.txt";
		
		Plain p = new Plain(fileName);
		
		State object = p.grid[1][1].next(p).who();
		
		assertEquals(State.RABBIT, object);
		
	}	
	
	

}

// Check AS
