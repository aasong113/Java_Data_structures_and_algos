 package hw1;

/**
 *  
 * @author Anthony Song
 *
 */

/**
 * A badger eats a rabbit and competes against a fox.
 */
public class Badger extends Animal {
	/**
	 * Constructor
	 * 
	 * @param p: plain
	 * @param r: row position
	 * @param c: column position
	 * @param a: age
	 */
	public Badger(Plain p, int r, int c, int a) {
		// TODO
		plain = p;
		row = r;
		column = c;
		age = a;
		// int[] population = new int[Living.NUM_LIFE_FORMS];

	}

	/**
	 * A badger occupies the square.
	 */
	public State who() {
		// TODO
		return State.BADGER;
	}

	/**
	 * A badger dies of old age or hunger, or from isolation and attack by a group
	 * of foxes.
	 * 
	 * @param pNew plain of the next cycle
	 * @return Living life form occupying the square in the next cycle.
	 */
	public Living next(Plain pNew) {

		// new array of zeros. 
		int[] population = new int[NUM_LIFE_FORMS];
		
		// call super class method in living to determine surroundings.
		
		census(population);

		/*
		 * BADGER = 0; EMPTY = 1;
		 * FOX = 2; GRASS = 3;
		 * RABBIT = 4;
		 */

		// If old badger dies.
		if (age == Living.BADGER_MAX_AGE) {

			return new Empty(pNew, row, column);
		}

		// If there is only one badger, but there are more than one fox. 
		if (population[0] == 1 && population[2] > 1) {
			return new Fox(pNew, row, column, 0);
		}

		// if badgers and foxes total outnumber rabbits, return empty square.
		if ((population[2] + (population[0])) > population[4]) {
			return new Empty(pNew, row, column);
		}
		
		// return badger of age + 1;
		age++;
		return this;

		// TODO
		//
		// See Living.java for an outline of the function.
		// See the project description for the survival rules for a badger.


	}
}

// Check AS