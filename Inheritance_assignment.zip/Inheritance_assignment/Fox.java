package hw1;

/**
 *  
 * @author Anthony Song
 *
 */

/**
 * A fox eats rabbits and competes against a badger.
 */
public class Fox extends Animal {
	/**
	 * Constructor
	 * 
	 * @param p: plain
	 * @param r: row position
	 * @param c: column position
	 * @param a: age
	 */
	public Fox(Plain p, int r, int c, int a) {
		// TODO

		plain = p;
		row = r;
		column = c;
		age = a;
	}

	/**
	 * A fox occupies the square.
	 */
	public State who() {
		// TODO
		return State.FOX;
	}

	/**
	 * A fox dies of old age or hunger, or from attack by numerically superior
	 * badgers.
	 * 
	 * @param pNew plain of the next cycle
	 * @return Living life form occupying the square in the next cycle.
	 */
	public Living next(Plain pNew) {
		
		
		int[] population = new int[NUM_LIFE_FORMS];
		
		// call super class method in living to determine surroundings.
		census(population);
		
		/*
		 * BADGER = 0; EMPTY = 1;
		 * FOX = 2; GRASS = 3;
		 * RABBIT = 4;
		 */
		
		// if fox is the age 6 it dies. 
		if(age == Living.FOX_MAX_AGE) {
			return new Empty( pNew, row, column);
		}
		
		// If badgers outnumber the number of foxes, return a badger of age zero. 
		if( population[0] > (population[2])) {
			return new Badger( pNew, row, column, 0);
		}
		
		// Empty if badgers and foxes together outnumber the rabbits. 
		if (  (population[0] + (population[2])) > population[4]) {
			return new Empty(pNew, row, column);
		}
		
		// returnt the fox with age + 1
		age++;
		return this; 
		
		// TODO
		//
		// See Living.java for an outline of the function.
		// See the project description for the survival rules for a fox.
	}
}