/*
 * @author Anthony Song
 */

package edu.iastate.cs228.hw3;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/*
 * This class is holds the main method to run the binary message tree decoding sequence. 
 * This outputs the coding scheme for each character and the message that is decoded using recursive pre order
 * binary tree traversal. 
 */
public class MsgTree_Main {

	/*
	 * Main method for the decoding of the MsgTree Object. Takes in a file name. 
	 */
	public static void main(String args[]) throws FileNotFoundException {


		// interface to enter the file name. Breaks if the filename is not entered correctly the first time. 
		System.out.println("Enter File Name:");

		Scanner input = new Scanner(System.in);

		File file = new File(input.next());

		input.close();

		Scanner sc1 = new Scanner(file);

		String code = "";
		String message = "";

		while (sc1.hasNext()) {

			String temp = sc1.nextLine();

			String test = temp.substring(0, 1);

			// if the line is the integer message line.
			try {
				Integer.parseInt(test);
				message = temp;
				break;
			} catch (NumberFormatException e) {

				// if code isnt empty, then you must add a new line character.
				if (!code.isEmpty()) {

					code += "\n";

				}

				// add to the code.
				code += temp;

			}

		}

		sc1.close();

		
		// create the tree.
		MsgTree t = new MsgTree(code);

		// Print codes
		System.out.println("character code");
		System.out.println("-------------------------");

		MsgTree.printCodes(t, "");

		System.out.println();
		System.out.println("MESSAGE:");

		// decode message.
		Decoder d = new Decoder();
		
		d.decode(t, message);
		
		
	}
	
	

	
	
	


}
