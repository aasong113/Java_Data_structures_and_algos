/*
 * @author Anthony Song
 */

package edu.iastate.cs228.hw3;

/*
 * This is a decoder class that has the decode public void method used to decode the message using the binary tree. 
 */

public class Decoder {

	
	/*
	 * @param codes this is the MsgTree object that is taken in.
	 * @param msg this is the binary msg file that can be decoded to relay a message. 
	 * Void Method that decodes the message and prints to the console.
	 */
	public void decode(MsgTree codes, String msg) {

		
		MsgTree root = codes;
		
		// Total characters for the statistics. 
		int totalChar = 0;
		double totalBits = 0;
		
		// while the message is not equal to zero. 
		while(msg.length() != 0) {
		
		// while we are not at a leaf node. 
		while (codes.left != null && codes.right != null) {

			// get the first value in the message. 
			String current = msg.substring(0, 1);

			// remove the first value from the entire substring. 
			msg = msg.substring(1, msg.length());

			// if 0 go left. 
			if (current.equals("0")) {

				codes = codes.left;
				totalBits ++;
			} 
			// else go right. 
			else {
				codes = codes.right;
				totalBits ++;
			}
		}

		System.out.print(codes.payLoadChar);
		
		totalChar ++;
		
		// start at the top of the tree again. 
		codes = root;

	}
		System.out.println();
		System.out.println();
		
		
		// EXTRA CREDIT: to print statistics of the bits per character and tree space saving efficiency compared to theoretical bits per character. 
		System.out.println("STATISTICS:");
		
		// used to round one decimal places
		System.out.println(String.format("%-16s         %-12s", "Avg bits/char:", (Math.floor(totalBits / ((double) totalChar) * 10))/10 ));
		
		
		System.out.println(String.format("%-16s        %-12s", "Total characters:", totalChar));
		
		// used to round two deicimal places
		System.out.println(String.format("%-16s         %-12s", "Space savings:", (Math.floor(100*((1 - totalBits / (totalChar * 8)) * 100)))/100 + "%" ));
		
		
		
		
	}
	
	
}
