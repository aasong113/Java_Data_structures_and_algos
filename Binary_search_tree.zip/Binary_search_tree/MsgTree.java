/*
 * @author Anthony Song
 */

package edu.iastate.cs228.hw3;

/*
 * This class creates a binary tree that has leaf nodes which have assigned character values. 
 * There are two methods in this class, one that prints the coding scheme assigned from the input file, 
 * and one that decodes the binary tree using the input file to produce a message.
 */
public class MsgTree {

	/*
	 * This is the assigned char value at the leaf node.
	 */
	public char payLoadChar;

	/*
	 * This is the left tree for binary tree.
	 */
	public MsgTree left;

	/*
	 * This is the right tree for binary tree.
	 */
	public MsgTree right;

	/*
	 * Need static char idx in the tree string for recursive solution. This keeps
	 * track of the place in the string.
	 */
	private static int staticCharIdx = 0;

	
	
	/*
	 * @param encodingString The encoding string used to create the binary tree. 
	 * This is the constructor that is recursively called to build the tree and its
	 * internal nodes. It takes in a string parameter that is from the file.
	 */
	public MsgTree(String encodingString) {

		// Recursive solutions
		// create new message tree with current.

		// terminating the recursion

		if (staticCharIdx > encodingString.length() - 1) {

			return;

		}

		// this is the current character.
		char current = encodingString.charAt(staticCharIdx);
		staticCharIdx++;

		// Check the char to see if you go left for right.
		// If internal node, call string, else create leaf node.

		if (current == '^') {

			if (this.left == null) {

				try {
					// update current
					current = encodingString.charAt(staticCharIdx);
				} catch (StringIndexOutOfBoundsException e) {

				}
				// if leaf node
				if (current != '^') {

					this.left = new MsgTree(current);

				}
				// if internal node
				else {

					this.left = new MsgTree(encodingString);

				}
			}

			staticCharIdx++;

			if (this.right == null) {

				try {
					// update current
					current = encodingString.charAt(staticCharIdx);
				} catch (StringIndexOutOfBoundsException e) {

				}

				// if right node
				if (current != '^') {

					this.right = new MsgTree(current);

				}
				// if internal node
				else {

					this.right = new MsgTree(encodingString);

				}

			}

		}

	}

	/*
	 * @param payloadChar this is the character that is stored at the leaf node. 
	 * Constructor for a single node with null children. This is the leaf node.
	 */
	public MsgTree(char payloadChar) {

		this.payLoadChar = payloadChar;

		// creates two null children.
		this.left = null;

		this.right = null;

	}

	/*
	 * @param root This is the binary tree that is used to determine the coding structure of each character. 
	 * @param code this is the string code that is printed out, corresponding to the character. 
	 * method to print characters and their binary codes
	 */
	public static void printCodes(MsgTree root, String code) {

		// uses preorder traversal
		// 1. Visit the root.
		// 2. Traverse the left subtree, i.e., call Preorder(left-subtree)
		// 3. Traverse the right subtree, i.e., call Preorder(right-subtree)

		// Each first character encountered refers to the left most leaf.
		// Each ^ refers to a splitting point or internal node.

		// if right and left roots are null, then return the character at the pay load
		// and its code.
		if (root.right == null && root.left == null) {

			// if new line character.
			if (root.payLoadChar == '\n') {
				System.out.println(String.format("   %-3s     %-12s", "\\n", code));
				return;
			}

			System.out.println(String.format("   %-3s     %-12s", root.payLoadChar, code));

			return;
		}

		// Pre Order traversal. In order to print codes you must remove the last
		// element.
		printCodes(root.left, code += 0);
		code = code.substring(0, code.length() - 1);

		printCodes(root.right, code += 1);
		code = code.substring(0, code.length() - 1);

	}


	

}

