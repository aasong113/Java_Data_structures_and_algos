/**
 * @author Anthony Song
 */
package hw2;
import hw2.Location;
import hw2.Map;
import hw2.Direction;
import hw2.Status;

public class CaveExplorer {
	/**
	 * @param Final int this is the max energy.
	 */
	public static final int MAX_ENERGY = 100 ;
	/**
	 * @param This is the time on the clock that is initialized with the constructor. 
	 */
	private int clock;	
	/**
	 * @param this is the map that is initialized with the constructor. 
	 */
	private Map map;
	/**
	 * @param this is the initial energy that is initialized with the constructor. 
	 */
	private int energy;
	/**
	 * @param This is the number of food items that is initialized with the constructor. 
	 */
	private int foodItems;
	/**
	 * @param This is the number of matches that is initialized in the constructor. 
	 */
	private int matches;
	/**
	 * @param this is the location that is initialized in the constructor. 
	 */
	private Location location;
	/**
	 * @boolean This is a boolean that states whether or not the explorer has the key.
	 */
	private boolean hasKey;
	/**
	 * @boolean This is a boolean that states whether or not the door is open. 
	 */
	private boolean doorOpen;
	/**
	 * @boolean This is a boolean that states whether or not the explorer has a jacket. 
	 */
	private boolean hasJacket;

	

	/**
	 * This constructor is the same as the other constructors except that the
	 * initial clock time, energy, number of food items, number of matches, and
	 * initial location are all set by the user.
	 * 
	 * @param map       = a given map
	 * @param clock     = time clock
	 * @param energy    = initial energy
	 * @param foodItems = number of food
	 * @param matches   = number of matches
	 * @param initial   = initial location
	 */

	public CaveExplorer(Map map, int clock, int energy, int foodItems, int matches, Location initial) {
		this.map = map;
		this.clock = clock;
		this.energy = Math.min(energy, MAX_ENERGY);
		this.foodItems = foodItems;
		this.matches = matches;
		location = initial;
		map.mark(initial, Status.PlAYER);
		
		hasKey = false;
		doorOpen = false;
		hasJacket = false;

		
	}

	/**
	 * Create a new CaveExplorer and place him/her at the given initial location.
	 * 
	 * @param map     = a given map
	 * @param initial = initial location
	 */
	public CaveExplorer(Map map, Location initial) {
		energy = MAX_ENERGY;
		clock = 100;
		matches = 10;
		foodItems = 1;
		this.map = map;
		this.location = initial;
		map.mark(initial, Status.PlAYER);
		
		hasKey = false;
		doorOpen = false;
		hasJacket = false;
	
	}

	/**
	 * Create a new CaveExplorer using the given Random generator. A new player's
	 * time clock is at 100, his/her energy is at MAX_ENERGY, carrying one food item
	 * and 10 matches. The initial location must be picked using the
	 * getRandomOpenLocation method of the Map class and the given Random generator.
	 * Additionally, on the map mark the Status of the cell where the player is at
	 * as PLAYER.
	 * 
	 * @param map       = a given map
	 * @param generator = a given Random generator.
	 */
	public CaveExplorer(Map map, java.util.Random generator) {
		this.map = map;
		clock = 100;
		energy = MAX_ENERGY;
		foodItems = 1;
		matches = 10;	
		location = map.getRandomOpenLocation(generator);
		map.mark(location, Status.PlAYER);
		
		hasKey = false;
		doorOpen = false;
		hasJacket = false;
	}

	/**
	 * Look towards the given direction. If no match is left, return "DARKNESS",
	 * otherwise return the status of the neighboring cell in the given direction.
	 * Use Status' toString method to get a String representation of a Status. The
	 * action consumes one match (if any) and one energy. The clock goes down by 1.
	 * 
	 * @param d = a direction
	 * @return what is visible in front of the explorer
	 */
	public java.lang.String look(Direction d) {
		Location scan = new Location(location.getRow(),location.getCol());
		clock = Math.max(clock - 1, 0);				
							

			if (d.equals(Direction.NORTH)) {
				scan.translate(-1, 0);	
			}	
			else if (d.equals(Direction.SOUTH)) {
				scan.translate(1, 0);
			} 
			else if (d.equals(Direction.EAST)) {
				scan.translate(0, 1);
			} 
			else if (d.equals(Direction.WEST)) {
				scan.translate(0, -1);
			}	
			if (matches > 0) {
				
				matches = Math.max(matches - 1, 0);
				energy = Math.max(energy - 1, 0);							

			return map.getCellStatus(scan).toString();
			}
		
			else {
			return (String) "DARKNESS";
			}
					
	
	}

	/**
	 * move one step towards the given direction. The move fails if the next
	 * location is WALL, or it is a DOOR and the player does not have the key. In
	 * each move attempt (even if it fails), one unit of energy is consumed, the
	 * clock runs down by 1. If the move is successful, the Status of the current
	 * cell is changed to "MARK" on the map if it was PLAYER, and the Status of the
	 * new location is changed to "PLAYER" if it was OPEN or MARK. The player loses
	 * all his/her energy if the new location is a PIT or WATER (without a JACKET).
	 * If the new location is WATER, the player loses half of his food items and his
	 * matches (using integer division), whether he has life JACKET or not.
	 * 
	 * @param d = direction
	 * @return true if the player can make the move.
	 */
	
	public boolean move(Direction d) {
		
		Location scan = new Location(location.getRow(),location.getCol()); // test point to scan directions
		Location og = new Location(location.getRow(),location.getCol());
		map.mark(og, Status.MARK);
		clock = Math.max(clock - 1, 0);
		energy = Math.max(energy - 1, 0);

		// Moves the player

		// Scan location with dummy point, then if there is a door or wall you can't

		if (d.equals(Direction.NORTH)) {
			scan.translate(-1, 0);
		} 
		else if (d.equals(Direction.SOUTH)) {
			scan.translate(1, 0);
		} 
		else if (d.equals(Direction.EAST)) {
			scan.translate(0, 1);
		} 
		else if (d.equals(Direction.WEST)) {
			scan.translate(0, -1);
		}
		
		if ((map.getCellStatus(scan) == Status.WALL)) {
			location = og;
			map.mark(location, Status.PlAYER);
			return false;
		}
		// is there a door?
		if (map.isDoor(scan) == true) {
			if (hasKey == true) {
				location = scan;
				return true;
				
			} else {
				location = og;
				return false;
			}
		}
	

		// Is there a PIT??
		if ((map.getCellStatus(scan)) == Status.PIT) {
			energy = 0;
		
		}
		// Is there WATER?
		if ((map.getCellStatus(scan) == Status.WATER) && (hasJacket == false)) {
			
			
			energy = 0;
			foodItems = (int) foodItems / 2;
			matches = (int) matches / 2;
			
		} 
		else if ((map.getCellStatus(scan) == Status.WATER) && (hasJacket == true)) {
			
			
			foodItems = (int) foodItems / 2;
			matches = (int) matches / 2;
			
		}

		if (map.getCellStatus(og) == Status.PlAYER) {
			map.mark(og, Status.MARK);
		}

		location = scan;

		if (map.getCellStatus(location) == Status.MARK || map.getCellStatus(location) == Status.OPEN) {
			map.mark(location, Status.PlAYER);
		}

		return true;
	}
	
	


	/**
	 * Taking a rest increases the energy by 10 (but not to surpass the MAX_ENERGY).
	 * The clock goes down by 10 each time this action is taken.
	 */
	public void rest() {
		clock = Math.max(clock - 10, 0);
		energy = Math.min(MAX_ENERGY, energy + 10);		
		
	}

	/**
	 * Eat consumes one food item. It increases the energy by 10 (but not to surpass
	 * the MAX_ENERGY). The clock goes down by 1 each time this method is called,
	 * even when there is no food item.
	 */
	public void eat() {
		clock = Math.max(0, clock - 1);

		if (foodItems > 0) {
			foodItems = foodItems - 1;
			energy = Math.min(MAX_ENERGY, energy + 10);
		}

	}

	/**
	 * If there is a key, or jacket, or food, or match on the current location,
	 * calling this method will pick up the item (20 of them, in the case of
	 * matches), and the Status of the current cell on the map is changed to
	 * "PLAYER", otherwise do nothing. The player's clock and energy is not affected
	 * by this action.
	 */
	public void pickUp() {
						
		if (map.getCellStatus(location) == Status.FOOD) {
			foodItems = foodItems +1;			
		}
		if (map.getCellStatus(location) == Status.KEY) {
			hasKey = true;
		}
		if (map.getCellStatus(location) == Status.JACKET) {
			hasJacket = true;
		}
		if (map.getCellStatus(location) == Status.MATCH) {
			matches = matches + 20;
		}
		map.mark(location, Status.PlAYER);
	}

	/**
	 * this method returns a list of resources that player currently has. This
	 * action consumes one unit of energy and the clock goes down by 1.
	 * 
	 * @return a String representation of resource available.
	 */
	public java.lang.String checkResource() {
		energy = Math.max(energy - 1, 0);
		clock = Math.max(0,clock -1);
		
						
		return ( "Clock: " + clock +
				", Energy: " + energy + 
				", Food Items: " + foodItems +
				", Matches: " + matches +
				", Has Jacket? " + hasJacket + 
				", Has Key? " + hasKey +
				", Distance to Key: " + map.distance2key(location) +
				", Distance to Exit: " + map.distance2exit(location)
				);
	}

	/**
	 * the player is still in the game if the clock has not run out AND he still has
	 * energy.
	 * @return if the player is still in the game.
	 */
	public boolean isAlive() {
		return ((energy > 0) && (clock > 0));
	}

	/**
	 * return true if the player reaches the cave exit.
	 * @return true if the player reaches the exit.
	 */
	public boolean hasWon() {
		return ((doorOpen == true) && map.getCellStatus(location).equals(Status.EXIT));
	}

	/**
	 * return true if the player has the key, which is needed to open the door.
	 * @return true if having the key, false otherwise.
	 */
	public boolean hasKey() {
		return hasKey;
	}

	/**
	 * return true if the player has the life jacket, false otherwise.
	 * @return true if having the jacket.
	 */
	public boolean hasJacket() {
		return hasJacket;
	}

	/**
	 * return the number of foodItem left
	 * @return the number of foodItem left
	 */
	public int getFoodItems() {
		return foodItems;
	}

	/**
	 * return the number of matches left
	 * @return the number of matches left
	 */

	public int getMatches() {
		return matches;
	}

	/**
	 * Return the map.
	 * @return the map
	 */
	public Map getMap() {
		return map;
	}

	/**
	 * return the clock time left
	 * @return time left
	 */
	public int getClock() {
		return clock;
	}

	/**
	 * return the current energy level of the player
	 * @return energy
	 */
	public int getEnergy() {
		return energy;
	}

	/**
	 * return the current location of the player
	 * @return location
	 */
	public Location getLocation() {
		return location;
	}

	/**
	 * jump in the given direction. The explorer will jump 3 steps in the given
	 * direction if energy is 75 or above, 2 steps if energy is 50 to 74, and 1 step
	 * if energy is less than 50, which moves him/her the same distance as a move()
	 * action does, but consumes more energy. The player cannot jump over WALL nor
	 * DOOR. The player can jump and land on a DOOR only if he/she has the key. Each
	 * jump consumes 25 units of energy even if it fails. Clock goes down by 1. If
	 * the jump is successful, the Status of the current cell on the map is changed
	 * to "MARK" if it was PLAYER, and the Status of the new location is changed to
	 * "PLAYER" if it was OPEN or MARK.
	 * 
	 * @param d = direction of jump.
	 * @return true if the jump is successful, false if otherwise.
	 */
	
	
	public boolean jump(Direction d) {
		
		boolean success = false;
		
		Location og = new Location(location);
		
		Status step1 = null;
		Status step2 = null;
		Status step3 = null;
		
		Location location1 = new Location(location);
		Location location2 = new Location(location);
		Location location3 = new Location(location);
		
		if (d.equals(Direction.NORTH)) {
			location1.translate(-1,0);
			step1 = map.getCellStatus(location1);
			location2.translate(-2,0);
			step2 = map.getCellStatus(location2);
			location3.translate(-3,0);
			step3 = map.getCellStatus(location3);
			}
		else if (d.equals(Direction.SOUTH)) {
			location1.translate(1,0);
			step1 = map.getCellStatus(location1);
			location2.translate(2,0);
			step2= map.getCellStatus(location2);
			location3.translate(3,0);
			step3 = map.getCellStatus(location3);
		}
		else if (d.equals(Direction.EAST)) {
			location1.translate(0,1);
			step1 = map.getCellStatus(location1);
			location2.translate(0,2);
			step2 = map.getCellStatus(location2);
			location3.translate(0,3);
			step3 = map.getCellStatus(location3);
		}
		else if (d.equals(Direction.WEST)) {
			location1.translate(0,-1);
			step1 = map.getCellStatus(location1);
			location2.translate(0,-2);
			step2 = map.getCellStatus(location2);
			location3.translate(0,-3);
			step3 = map.getCellStatus(location3);
		}
		
		
		if ((energy >= 75) && (step1 != Status.WALL) && (step2 != Status.WALL) && (step3 != Status.WALL) && (step1 != Status.DOOR) && (step2 != Status.DOOR)) {
			if ((step3 == Status.FOOD) || (step3 == Status.JACKET) || (step3 == Status.MATCH) || (step3 == Status.KEY) || (step3 == Status.EXIT)) {
				map.mark(location, Status.MARK);
				location = location3;
			}
			else if ((step3 == Status.OPEN) || (step3 == Status.MARK)) {
				map.mark(location, Status.MARK);
				location = location3;
				map.mark(location, Status.PlAYER);
			}
			else if ((step3 == Status.DOOR) && (hasKey == true)) {
				map.mark(location, Status.MARK);
				doorOpen = true;
				location = location3;
			}
			else if ((step3 == Status.DOOR) && (hasKey == false)) {
				location = og;
				map.mark(location, Status.MARK);
			} 	
			else {
				location = og;
			}
		}
		
		
	if ((energy < 75) && (energy >= 50) && (step1 != Status.WALL) && (step2 != Status.WALL) && (step1 != Status.DOOR)) {
		if ((step2 == Status.FOOD) || (step2 == Status.JACKET) || (step2 == Status.MATCH) || (step2 == Status.KEY) || (step2 == Status.EXIT)) {
			map.mark(location, Status.MARK);
			location = location2;
		}
		else if ((step2 == Status.OPEN) || (step2 == Status.MARK)) {
			map.mark(location, Status.MARK);
			location = location2;
			map.mark(location, Status.PlAYER);
		}
		else if ((step2 == Status.DOOR) && (hasKey == true)) {
			map.mark(location, Status.MARK);
			doorOpen = true;
			location = location2;
		}
		else if ((step2 == Status.DOOR) && (hasKey == false)) {
			location = og;
			map.mark(location, Status.MARK);
		}
		else { 
			location = og;
		}
	}
	
	if ((energy < 50) && (step1 != Status.WALL)) {
		
		if ((step1 == Status.FOOD) || (step1 == Status.JACKET) || (step1 == Status.MATCH) || (step1 == Status.KEY) || (step1 == Status.EXIT)) {
			map.mark(location, Status.MARK);
			location = location1;
		}		
		else if ((step1 == Status.OPEN) || (step1 == Status.MARK)) {
			map.mark(location, Status.MARK);
			location = location1;
			map.mark(location, Status.PlAYER);
		}
		else if ((step1 == Status.DOOR) && (hasKey == true)) {
			map.mark(location, Status.MARK);
			doorOpen = true;
			location = location1;
		}
		else if ((step1 == Status.DOOR) && (hasKey == false)) {
			location = og;
			map.mark(location, Status.MARK);
		} 	
		else {
			location = og;
		}	
	}
	
		
	// Check for water hazards 
	if ((map.getCellStatus(location) == Status.WATER) && (hasJacket == true)) {
		map.mark(location, Status.MARK);
		foodItems /= 2;
		matches /= 2;
	}
	else if ((map.getCellStatus(location) == Status.WATER) && (hasJacket == false)) {
		map.mark(location, Status.MARK);
		energy = 0;
		foodItems /= 2;
		matches /= 2;
	}
	// Check for pit hazards. 
	else if (map.getCellStatus(location) == Status.PIT) {
		map.mark(location, Status.MARK);
		energy = 0;
		}	
	
	energy = Math.max(energy - 25, 0);
	clock = Math.max(clock - 1, 0);
	
	
	if (location != og) {
		success = true;
	}
	
	return success;
}	            		
// Submit this version - Song - 2.0
}	








